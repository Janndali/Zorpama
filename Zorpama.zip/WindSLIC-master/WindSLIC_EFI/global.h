#ifndef GLOABAL_H
#define GLOABAL_H
//
#include <efi.h>
//
EFI_SYSTEM_TABLE *ST;
EFI_BOOT_SERVICES *BS;
EFI_RUNTIME_SERVICES *RS;
//
#endif