// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
#define WIN32_NO_STATUS
#include <Windows.h>
#include <winternl.h>
#include <fstream>
#undef WIN32_NO_STATUS
#include <ntstatus.h>
#include <WinError.h>
#include <time.h>
#include "../libinstaller/libinstaller.h"



// TODO: reference additional headers your program requires here
