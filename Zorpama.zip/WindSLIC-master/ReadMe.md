WindSLIC SLIC injectors
=======================

includes UEFI, NTFS, bootmgr SLIC injectors and installers.